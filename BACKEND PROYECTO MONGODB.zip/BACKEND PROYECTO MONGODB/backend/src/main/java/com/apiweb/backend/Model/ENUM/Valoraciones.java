package com.apiweb.backend.Model.ENUM;

public enum Valoraciones {
    MuyMala,Mala,Neutra,Buena,MuyBuena
}
