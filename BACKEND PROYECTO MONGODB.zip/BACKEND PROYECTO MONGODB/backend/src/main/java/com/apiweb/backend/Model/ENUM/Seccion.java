package com.apiweb.backend.Model.ENUM;

public enum Seccion {
    Hombre, Mujer, Nino
}
