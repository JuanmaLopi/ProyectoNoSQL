package com.apiweb.backend.Model.ENUM;

public enum Genero {
    H,M
}
