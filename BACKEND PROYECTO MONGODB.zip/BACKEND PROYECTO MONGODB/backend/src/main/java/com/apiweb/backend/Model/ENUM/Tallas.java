package com.apiweb.backend.Model.ENUM;

public enum Tallas {
    XS,S,M,L,XL
}
