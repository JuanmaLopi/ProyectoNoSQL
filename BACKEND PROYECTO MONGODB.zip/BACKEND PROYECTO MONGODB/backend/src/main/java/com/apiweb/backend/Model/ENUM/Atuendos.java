package com.apiweb.backend.Model.ENUM;

public enum Atuendos {
    Sudaderas,Camisetas,Calcetines,Pantalonetas,Leggins,Zapatillas
}
